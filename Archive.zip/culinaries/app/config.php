<?php
    error_reporting(0);

    require '../../database/connection.php';
    date_default_timezone_set('Asia/Jakarta');

    $created_at = date('Y-m-d H:i:s');
    $updated_at = date('Y-m-d H:i:s');
