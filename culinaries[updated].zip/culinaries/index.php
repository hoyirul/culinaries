<?php

    header('location:./page/');