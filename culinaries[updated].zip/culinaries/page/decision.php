<?php session_start(); ?>
<?php if($_SESSION['sess_id']): ?>
    <a href="./../admin/" class="btn btn-app">Dashboard</a>
<?php else: ?>
    <a href="./../auth/auth.php" class="btn btn-app">Masuk</a>
<?php endif ?>